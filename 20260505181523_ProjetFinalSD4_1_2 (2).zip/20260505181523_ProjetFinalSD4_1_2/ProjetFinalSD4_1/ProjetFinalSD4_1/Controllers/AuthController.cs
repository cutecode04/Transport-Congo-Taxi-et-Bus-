﻿using Microsoft.AspNetCore.Mvc;
using ProjetFinalSD4_1.Service;
using ProjetFinalSD4_1.Models;

namespace ProjetFinalSD4_1.Controllers
{
    [ApiController]
    [Route("api/auth")]
    public class AuthController : ControllerBase
    {
        [HttpPost("login")]
        public IActionResult Login(LoginDto login)
        {
            ServiceDB service = new ServiceDB();
            var user = service.Connexion(login.Telephone, login.MotDePasse);

            if (user == null)
                return Unauthorized("Identifiants incorrects");

            return Ok(user);
        }
    }
}