﻿using Microsoft.AspNetCore.Mvc;
using ProjetFinalSD4_1.Models;
using ProjetFinalSD4_1.Service;
using ProjetFinalSD4_1.Services;

namespace ProjetFinalSD4_1.Controllers
{
    [ApiController]
    [Route("api/courses")]
    public class CourseController : ControllerBase
    {
        private readonly CourseService _service;

        public CourseController(IConfiguration config)
        {
            string cs = config.GetConnectionString("DefaultConnection");
            _service = new CourseService(cs);
        }

        [HttpPost]
        public IActionResult CreerCourse([FromBody] CourseDto dto)
        {
            if (dto == null || dto.ClientId <= 0)
                return Unauthorized("Connexion requise pour commander une course");

            _service.AjouterCourse(dto);

            return Ok("Course créée avec succès");
        }
        [HttpPut("accepter/{id}")]
        public IActionResult Accepter(int id, [FromQuery] int chauffeurId)
        {
            ServiceDB service = new ServiceDB();
            service.AccepterCourse(id, chauffeurId);
            return Ok();
        }

        [HttpPut("refuser/{id}")]
        public IActionResult Refuser(int id)
        {
            ServiceDB service = new ServiceDB();
            service.RefuserCourse(id);
            return Ok();
        }

        [HttpGet("client/{clientId}")]
        public IActionResult GetCoursesClient(int clientId)
        {
            return Ok(_service.GetCoursesClient(clientId));
        }

        [HttpGet("stats/client/{clientId}")]
        public IActionResult GetStatsClient(int clientId)
        {
            return Ok(_service.GetStatsClient(clientId));
        }
    }
}