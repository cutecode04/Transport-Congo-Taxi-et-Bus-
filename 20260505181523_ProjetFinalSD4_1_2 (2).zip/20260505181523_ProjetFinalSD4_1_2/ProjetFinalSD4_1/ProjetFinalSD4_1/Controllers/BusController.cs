﻿using Microsoft.AspNetCore.Mvc;
using ProjetFinalSD4_1.Service;

namespace ProjetFinalSD4_1.Controllers
{
    [ApiController]
    [Route("api/bus")]
    public class BusController : ControllerBase
    {
        private readonly BusService service = new BusService();

        [HttpGet]
        public IActionResult GetHoraires()
        {
            return Ok(service.GetTousLesHoraires());
        }

        [HttpGet("ligne/{ligne}")]
        public IActionResult GetParLigne(string ligne)
        {
            return Ok(service.GetHorairesParLigne(ligne));
        }
    }
}