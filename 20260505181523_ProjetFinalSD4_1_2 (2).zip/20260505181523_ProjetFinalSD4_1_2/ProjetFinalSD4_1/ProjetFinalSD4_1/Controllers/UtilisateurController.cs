﻿using Microsoft.AspNetCore.Mvc;
using ProjetFinalSD4_1.Models;
using ProjetFinalSD4_1.Service;

namespace ProjetFinalSD4_1.Controllers
{
    [ApiController]
    [Route("api/utilisateurs")]
    public class UtilisateurController : ControllerBase
    {
        // ✅ GET : récupérer les utilisateurs
        [HttpGet]
        public IActionResult GetUtilisateurs()
        {
            ServiceDB service = new ServiceDB();
            var resultat = service.ChargerUtilisateursJson();
            return Ok(resultat);
        }

        // ✅ POST : créer un utilisateur
        [HttpPost]
        public IActionResult AjouterUtilisateur([FromBody] UtilisateurDTO user)
        {
            if (user == null)
                return BadRequest("Données invalides");

            try
            {
                ServiceDB service = new ServiceDB();
                service.AjouterUtilisateurDto(user);
                return Ok("Utilisateur ajouté");
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }
    }
}