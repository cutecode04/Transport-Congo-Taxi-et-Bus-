﻿using Microsoft.AspNetCore.Mvc;
using ProjetFinalSD4_1.Service;

namespace ProjetFinalSD4_1.Controllers
{
    [ApiController]
    [Route("api/admin")]
    public class AdminController : ControllerBase
    {
        private readonly ServiceDB service = new ServiceDB();

        // ✅ UTILISATEURS
        [HttpGet("utilisateurs")]
        public IActionResult TousLesUtilisateurs([FromQuery] string role)
        {
            if (role != "Administrateur")
                return Unauthorized("Accès réservé à l'administrateur");

            return Ok(service.ChargerUtilisateursJson());
        }

        // ✅ COURSES
        [HttpGet("courses")]
        public IActionResult ToutesLesCourses([FromQuery] string role)
        {
            if (role != "Administrateur")
                return Unauthorized("Accès réservé à l'administrateur");

            var courses = service.ChargerCourses();
            return Ok(courses);
        }

        // ✅ ACTIVITÉS RÉCENTES (BD)
        [HttpGet("activites")]
        public IActionResult GetActivites()
        {
            var activites = service.GetDernieresCourses();
            return Ok(activites);
        }
    }
}