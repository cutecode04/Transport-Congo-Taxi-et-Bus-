﻿using Microsoft.Data.SqlClient;
using ProjetFinalSD4_1.Data;
using ProjetFinalSD4_1.Models;

namespace ProjetFinalSD4_1.Service
{
    public class BusService
    {
        public List<BusHoraire> GetTousLesHoraires()
        {
            List<BusHoraire> liste = new List<BusHoraire>();

            using SqlConnection con = BaseDeDonnee.GetConnection();
            con.Open();

            string sql = "SELECT * FROM BusHoraires ORDER BY Ligne, Heure";

            SqlCommand cmd = new SqlCommand(sql, con);
            SqlDataReader reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                BusHoraire b = new BusHoraire();

                b.Id = Convert.ToInt32(reader["Id"]);
                b.Ligne = reader["Ligne"].ToString();
                b.Depart = reader["Depart"].ToString();
                b.Arrivee = reader["Arrivee"].ToString();
                b.Heure = reader["Heure"].ToString();
                b.Frequence = reader["Frequence"].ToString();

                liste.Add(b);
            }

            return liste;
        }

        public List<BusHoraire> GetHorairesParLigne(string ligne)
        {
            List<BusHoraire> liste = new List<BusHoraire>();

            using SqlConnection con = BaseDeDonnee.GetConnection();
            con.Open();

            string sql = @"SELECT * FROM BusHoraires 
                           WHERE Ligne LIKE @ligne 
                           ORDER BY Heure";

            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.Parameters.AddWithValue("@ligne", "%" + ligne + "%");

            SqlDataReader reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                BusHoraire b = new BusHoraire();

                b.Id = Convert.ToInt32(reader["Id"]);
                b.Ligne = reader["Ligne"].ToString();
                b.Depart = reader["Depart"].ToString();
                b.Arrivee = reader["Arrivee"].ToString();
                b.Heure = reader["Heure"].ToString();
                b.Frequence = reader["Frequence"].ToString();

                liste.Add(b);
            }

            return liste;
        }
    }
}