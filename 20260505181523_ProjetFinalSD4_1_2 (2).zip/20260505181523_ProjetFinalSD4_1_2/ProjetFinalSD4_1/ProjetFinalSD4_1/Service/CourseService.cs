﻿using Microsoft.Data.SqlClient;
using ProjetFinalSD4_1.Models;

namespace ProjetFinalSD4_1.Services
{
    public class CourseService
    {
        private readonly string _connectionString;

        public CourseService(string connectionString)
        {
            _connectionString = connectionString;
        }

        // AJOUTER UNE COURSE
        public void AjouterCourse(CourseDto dto)
        {
            using SqlConnection conn = new SqlConnection(_connectionString);
            conn.Open();

            string sql = @"INSERT INTO Courses
                (ClientId, ChauffeurId, LieuDepart, LieuArrivee, TypeCourse, Montant, ModePaiement, Statut, DateCommande)
                VALUES
                (@clientId, @chauffeurId, @depart, @arrivee, @type, @montant, @paiement, @statut, @dateCommande)";

            SqlCommand cmd = new SqlCommand(sql, conn);

            cmd.Parameters.AddWithValue("@clientId", dto.ClientId);
            cmd.Parameters.AddWithValue("@chauffeurId", DBNull.Value);
            cmd.Parameters.AddWithValue("@depart", dto.LieuDepart);
            cmd.Parameters.AddWithValue("@arrivee", dto.LieuArrivee);
            cmd.Parameters.AddWithValue("@type", dto.TypeCourse);
            cmd.Parameters.AddWithValue("@montant", dto.Montant);
            cmd.Parameters.AddWithValue("@paiement", dto.ModePaiement);
            cmd.Parameters.AddWithValue("@statut", "EnAttente");
            cmd.Parameters.AddWithValue("@dateCommande", DateTime.Now);

            cmd.ExecuteNonQuery();
        }

        // HISTORIQUE CLIENT
        public List<Course> GetCoursesClient(int clientId)
        {
            List<Course> courses = new List<Course>();

            using SqlConnection conn = new SqlConnection(_connectionString);
            conn.Open();

            string sql = @"SELECT Id, ClientId, ChauffeurId, LieuDepart, LieuArrivee,
                                  TypeCourse, Montant, ModePaiement, Statut, DateCommande
                           FROM Courses
                           WHERE ClientId = @clientId
                           ORDER BY DateCommande DESC";

            SqlCommand cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@clientId", clientId);

            SqlDataReader reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                Course c = new Course();

                c.Id = Convert.ToInt32(reader["Id"]);
                c.ClientId = Convert.ToInt32(reader["ClientId"]);

                if (reader["ChauffeurId"] == DBNull.Value)
                    c.ChauffeurId = null;
                else
                    c.ChauffeurId = Convert.ToInt32(reader["ChauffeurId"]);

                c.LieuDepart = reader["LieuDepart"].ToString();
                c.LieuArrivee = reader["LieuArrivee"].ToString();
                c.TypeCourse = reader["TypeCourse"].ToString();
                c.Montant = Convert.ToDecimal(reader["Montant"]);
                c.ModePaiement = reader["ModePaiement"].ToString();
                c.Statut = Enum.Parse<StatuCourse>(reader["Statut"].ToString());
                c.DateCommande = Convert.ToDateTime(reader["DateCommande"]);

                courses.Add(c);
            }

            return courses;
        }

        // STATISTIQUES CLIENT
        public object GetStatsClient(int clientId)
        {
            using SqlConnection conn = new SqlConnection(_connectionString);
            conn.Open();

            SqlCommand cmdTotal = new SqlCommand(
                "SELECT COUNT(*) FROM Courses WHERE ClientId=@clientId", conn);
            cmdTotal.Parameters.AddWithValue("@clientId", clientId);
            int total = Convert.ToInt32(cmdTotal.ExecuteScalar());

            SqlCommand cmdAttente = new SqlCommand(
                "SELECT COUNT(*) FROM Courses WHERE ClientId=@clientId AND Statut='EnAttente'", conn);
            cmdAttente.Parameters.AddWithValue("@clientId", clientId);
            int enAttente = Convert.ToInt32(cmdAttente.ExecuteScalar());

            SqlCommand cmdTerminees = new SqlCommand(
                "SELECT COUNT(*) FROM Courses WHERE ClientId=@clientId AND Statut='Terminee'", conn);
            cmdTerminees.Parameters.AddWithValue("@clientId", clientId);
            int terminees = Convert.ToInt32(cmdTerminees.ExecuteScalar());

            return new
            {
                total,
                enAttente,
                terminees
            };
        }
    }
}