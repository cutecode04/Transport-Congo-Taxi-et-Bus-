﻿using Microsoft.Data.SqlClient;
using ProjetFinalSD4_1.Data;
using ProjetFinalSD4_1.Models;
using System;
using System.Collections.Generic;
using System.Data;

namespace ProjetFinalSD4_1.Service
{
    public class ServiceDB
    {
        // =============================
        // UTILISATEURS
        // =============================

        public bool AdministrateurExiste()
        {
            using SqlConnection con = BaseDeDonnee.GetConnection();
            con.Open();

            string sql = "SELECT COUNT(*) FROM Utilisateurs WHERE Role='Administrateur'";
            SqlCommand cmd = new SqlCommand(sql, con);

            return Convert.ToInt32(cmd.ExecuteScalar()) > 0;
        }

        public void AjouterUtilisateurDto(UtilisateurDTO user)
        {
            // ✅ Comparaison ENUM → ENUM
            if (user.Role == "Administrateur" && AdministrateurExiste())
                throw new Exception("Un administrateur existe déjà.");

            using SqlConnection con = BaseDeDonnee.GetConnection();
            con.Open();

            string sql = @"INSERT INTO Utilisateurs
                           (Nom, Telephone, MotDePasse, Role, Disponible)
                           VALUES (@nom, @tel, @mdp, @role, @disp)";

            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.Parameters.AddWithValue("@nom", user.Nom);
            cmd.Parameters.AddWithValue("@tel", user.Telephone);
            cmd.Parameters.AddWithValue("@mdp", user.MotDePasse);
            cmd.Parameters.AddWithValue("@role", user.Role.ToString()); // ✅ enum → string
            cmd.Parameters.AddWithValue("@disp", user.Disponible ? 1 : 0);

            cmd.ExecuteNonQuery();
        }
        public List<Dictionary<string, object>> ChargerCoursesJson()
        {
            DataSet ds = new DataSet();

            using (SqlConnection con = BaseDeDonnee.GetConnection())
            {
                con.Open();

                string sql = "SELECT * FROM Courses ORDER BY DateCommande DESC";
                SqlDataAdapter da = new SqlDataAdapter(sql, con);

                da.Fill(ds, "Courses");
            }

            DataTable table = ds.Tables["Courses"];
            List<Dictionary<string, object>> result = new();

            foreach (DataRow row in table.Rows)
            {
                Dictionary<string, object> dict = new();

                foreach (DataColumn col in table.Columns)
                {
                    dict[col.ColumnName] = row[col];
                }

                result.Add(dict);
            }

            return result;
        }
        public void AccepterCourse(int id, int chauffeurId)
        {
            using SqlConnection con = BaseDeDonnee.GetConnection();
            con.Open();

            string sql = @"UPDATE Courses 
                   SET Statut='EnCours', ChauffeurId=@chauffeur
                   WHERE Id=@id";

            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.Parameters.AddWithValue("@id", id);
            cmd.Parameters.AddWithValue("@chauffeur", chauffeurId);

            cmd.ExecuteNonQuery();
        }

        public void RefuserCourse(int id)
        {
            using SqlConnection con = BaseDeDonnee.GetConnection();
            con.Open();

            string sql = @"UPDATE Courses 
                   SET Statut='Annulee'
                   WHERE Id=@id";

            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.Parameters.AddWithValue("@id", id);

            cmd.ExecuteNonQuery();
        }
        public List<Dictionary<string, object>> ChargerCourses()
        {
            List<Dictionary<string, object>> courses = new();

            using SqlConnection con = BaseDeDonnee.GetConnection();
            con.Open();

            string sql = @"SELECT 
                    Id,
                    ClientId,
                    ChauffeurId,
                    LieuDepart,
                    LieuArrivee,
                    TypeCourse,
                    Montant,
                    ModePaiement,
                    Statut
                   FROM Courses";

            SqlCommand cmd = new SqlCommand(sql, con);
            SqlDataReader reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                courses.Add(new Dictionary<string, object>
                {
                    ["Id"] = reader["Id"],
                    ["ClientId"] = reader["ClientId"],
                    ["ChauffeurId"] = reader["ChauffeurId"],
                    ["LieuDepart"] = reader["LieuDepart"],
                    ["LieuArrivee"] = reader["LieuArrivee"],
                    ["TypeCourse"] = reader["TypeCourse"],
                    ["Montant"] = reader["Montant"],
                    ["ModePaiement"] = reader["ModePaiement"],
                    ["Statut"] = reader["Statut"]
                });
            }

            return courses;
        }
        public object GetAdminStats()
        {
            using SqlConnection con = BaseDeDonnee.GetConnection();
            con.Open();

            SqlCommand cmdUsers = new(
                "SELECT COUNT(*) FROM Utilisateurs", con);

            SqlCommand cmdCourses = new(
                "SELECT COUNT(*) FROM Courses", con);

            int utilisateurs = (int)cmdUsers.ExecuteScalar();
            int courses = (int)cmdCourses.ExecuteScalar();

            return new
            {
                utilisateurs,
                courses
            };
        }
        public List<object> GetDernieresCourses()
        {
            List<object> list = new List<object>();

            using SqlConnection con = BaseDeDonnee.GetConnection();
            con.Open();

            string sql = @"SELECT TOP 5
                   ClientId,
                   LieuDepart,
                   LieuArrivee,
                   DateCommande
                   FROM Courses
                   ORDER BY DateCommande DESC";

            SqlCommand cmd = new SqlCommand(sql, con);
            SqlDataReader reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                list.Add(new
                {
                    clientId = reader["ClientId"],
                    depart = reader["LieuDepart"].ToString(),
                    arrivee = reader["LieuArrivee"].ToString(),
                    date = reader["DateCommande"]
                });
            }

            return list;
        }
        public UtilisateurDTO Connexion(string telephone, string motDePasse)
        {
            using SqlConnection con = BaseDeDonnee.GetConnection();
            con.Open();

            string sql = @"SELECT Id, Nom, Telephone, MotDePasse, Role, Disponible
                   FROM Utilisateurs
                   WHERE Telephone=@tel AND MotDePasse=@mdp";

            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.Parameters.AddWithValue("@tel", telephone);
            cmd.Parameters.AddWithValue("@mdp", motDePasse);

            SqlDataReader reader = cmd.ExecuteReader();

            if (!reader.Read())
                return null;

            return new UtilisateurDTO
            {
                Id = Convert.ToInt32(reader["Id"]),
                Nom = reader["Nom"].ToString(),
                Telephone = reader["Telephone"].ToString(),
                MotDePasse = reader["MotDePasse"].ToString(),
                Role = reader["Role"].ToString(),
                Disponible = Convert.ToBoolean(reader["Disponible"])
            };
        }

        // =============================
        // COURSES
        // =============================

        public void AjouterCourse(Course c)
        {
            using SqlConnection con = BaseDeDonnee.GetConnection();
            con.Open();

            string sql = @"INSERT INTO Courses
            (ClientId, ChauffeurId, LieuDepart, LieuArrivee, TypeCourse, Montant, ModePaiement, Statut)
            VALUES (@client, @chauffeur, @depart, @arrivee, @type, @montant, @paiement, @statut)";

            SqlCommand cmd = new SqlCommand(sql, con);

            cmd.Parameters.AddWithValue("@client", c.ClientId);
            cmd.Parameters.AddWithValue("@chauffeur", (object?)c.ChauffeurId ?? DBNull.Value);
            cmd.Parameters.AddWithValue("@depart", c.LieuDepart);
            cmd.Parameters.AddWithValue("@arrivee", c.LieuArrivee);
            cmd.Parameters.AddWithValue("@type", c.TypeCourse);
            cmd.Parameters.AddWithValue("@montant", c.Montant);
            cmd.Parameters.AddWithValue("@paiement", c.ModePaiement);
            cmd.Parameters.AddWithValue("@statut", c.Statut.ToString());

            cmd.ExecuteNonQuery();
        }

        public int? TrouverChauffeurDisponible()
        {
            using SqlConnection con = BaseDeDonnee.GetConnection();
            con.Open();

            string sql = "SELECT TOP 1 Id FROM Utilisateurs WHERE Role='Chauffeur' AND Disponible=1";
            SqlCommand cmd = new SqlCommand(sql, con);

            var result = cmd.ExecuteScalar();
            return result != null ? Convert.ToInt32(result) : null;
        }

        public List<Dictionary<string, object>> ChargerUtilisateursJson()
        {
            DataSet ds = new DataSet();

            using (SqlConnection con = BaseDeDonnee.GetConnection())
            {
                con.Open();

                string sql = "SELECT * FROM Utilisateurs ORDER BY Id DESC";
                SqlDataAdapter da = new SqlDataAdapter(sql, con);

                da.Fill(ds, "Utilisateurs");
            }

            DataTable table = ds.Tables["Utilisateurs"];
            List<Dictionary<string, object>> result = new();

            foreach (DataRow row in table.Rows)
            {
                Dictionary<string, object> dict = new();

                foreach (DataColumn col in table.Columns)
                {
                    dict[col.ColumnName] = row[col];
                }

                result.Add(dict);
            }

            return result;
        }
    }
}