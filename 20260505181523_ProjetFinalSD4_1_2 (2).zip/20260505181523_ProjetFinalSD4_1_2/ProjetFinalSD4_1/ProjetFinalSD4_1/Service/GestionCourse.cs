﻿using ProjetFinalSD4_1.Models;
using System.Security.Cryptography.X509Certificates;

namespace ProjetFinalSD4_1.Service
{
           public class GestionCourse
        {
       
            // Courses standard : FIFO (O(1))
            private Queue<Course> fileStandard = new();

            // Courses VIP : priorité (O(log n))
            private PriorityQueue<Course, int> fileVIP = new();

            // Historique (consultation admin)
            private List<Course> historique = new();

            private int id = 1;

            public Course CommanderCourse(int clientId, string depart, string arrivee,
                                         string type, decimal montant, string paiement)
            {
                Course c = new Course
                {
                    Id = id++,
                    ClientId = clientId,
                    LieuDepart = depart,
                    LieuArrivee = arrivee,
                    TypeCourse = type,
                    Montant = montant,
                    ModePaiement = paiement,
                    Statut = StatuCourse.EnAttente
                };

                if (type == "VIP")
                    fileVIP.Enqueue(c, 1);
                else
                    fileStandard.Enqueue(c);

                historique.Add(c);
                return c;
            }

            // Chauffeur prend la prochaine course prioritaire
            public Course? AssignerProchaineCourse()
            {
                if (fileVIP.Count > 0)
                    return fileVIP.Dequeue();

                if (fileStandard.Count > 0)
                    return fileStandard.Dequeue();

                return null;
            }

            // Accès administrateur
            public List<Course> HistoriqueCourses()
            {
                return historique;
            }
        }

    }



