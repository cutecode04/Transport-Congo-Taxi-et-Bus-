﻿using ProjetFinalSD4_1.Models;
using System.Security.Cryptography.X509Certificates;

namespace ProjetFinalSD4_1.Service
{
    public class GestionUtilisateur
    {
       
            // Complexité : O(n) pour la recherche
            private List<Utilisateur> lesUtilisateurs = new();

            private int _id = 1;

            //  Inscription générique selon le rôle
            public Utilisateur Inscrire(string nom, string tel, string mdp, RoleUtilisateur role)
            {
                // Vérifier unicité du téléphone (O(n))
                foreach (Utilisateur u in lesUtilisateurs)
                {
                    if (u.Telephone == tel)
                        throw new Exception("Téléphone déjà utilisé");
                }

                // Création de l'utilisateur
                Utilisateur utilisateur = new Utilisateur
                {
                    Id = _id++,
                    Nom = nom,
                    Telephone = tel,
                    MotDePasse = mdp,
                    Role = role
                };

                // Si chauffeur, il est disponible par défaut
                if (role == RoleUtilisateur.Chauffeur && utilisateur is Chauffeur chauffeur)
                {
                    chauffeur.Disponible = true;
                }

                lesUtilisateurs.Add(utilisateur);
                return utilisateur;
            }

            //  Connexion : recherche linéaire O(n)
            public Utilisateur? Connecter(string tel, string mdp)
            {
                foreach (Utilisateur u in lesUtilisateurs)
                {
                    if (u.Telephone == tel && u.MotDePasse == mdp)
                        return u;
                }
                return null;
            }

            // Accès administrateur uniquement
            public List<Utilisateur> TousLesUtilisateurs(Utilisateur demandeur)
            {
                if (demandeur.Role != RoleUtilisateur.Administrateur)
                    throw new UnauthorizedAccessException("Accès réservé à l’administrateur");

                return lesUtilisateurs;
            }
        }
    }



   




