﻿using ProjetFinalSD4_1.Models;

namespace ProjetFinalSD4_1.Service
{
        public class GestionBus
        {
            // clé = ligne de bus
            // valeur = liste des horaires
            private Dictionary<string, List<BusHoraire>> horaires =
                new Dictionary<string, List<BusHoraire>>();

            // Charger les horaires depuis la base de données
            public void ChargerHoraires(List<BusHoraire> liste)
            {
                foreach (BusHoraire b in liste)
                {
                    if (!horaires.ContainsKey(b.Ligne))
                    {
                        horaires[b.Ligne] = new List<BusHoraire>();
                    }

                    horaires[b.Ligne].Add(b);
                }
            }

            // Obtenir les horaires d’une ligne
            public List<BusHoraire>? HorairesParLigne(string ligne)
            {
                if (horaires.ContainsKey(ligne))
                {
                    return horaires[ligne];
                }

                return null;
            }

            // Obtenir toutes les lignes
            public List<string> ToutesLesLignes()
            {
                List<string> lignes = new List<string>();

                foreach (string cle in horaires.Keys)
                {
                    lignes.Add(cle);
                }

                return lignes;
            }
        }
    }



