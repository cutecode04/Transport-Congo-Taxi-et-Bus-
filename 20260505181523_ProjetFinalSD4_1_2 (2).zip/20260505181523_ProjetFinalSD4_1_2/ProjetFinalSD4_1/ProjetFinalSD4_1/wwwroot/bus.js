﻿async function chargerHorairesBus() {
    const response = await fetch("/api/bus");
    const horaires = await response.json();

    afficherHoraires(horaires);
}

async function rechercherLigne() {
    const ligne = document.getElementById("ligneRecherche").value.trim();

    if (ligne === "") {
        alert("Veuillez entrer une ligne.");
        return;
    }

    const response = await fetch(`/api/bus/ligne/${ligne}`);
    const horaires = await response.json();

    afficherHoraires(horaires);
}

function afficherHoraires(horaires) {
    const container = document.getElementById("listeBus");
    container.innerHTML = "";

    if (horaires.length === 0) {
        container.innerHTML = "<p>Aucun horaire trouvé.</p>";
        return;
    }

    horaires.forEach(b => {
        container.innerHTML += `
            <div class="bus-card">
                <h2>🚌 ${b.ligne}</h2>
                <p><strong>Départ :</strong> ${b.depart}</p>
                <p><strong>Arrivée :</strong> ${b.arrivee}</p>
                <p><strong>Fréquence :</strong> ${b.frequence}</p>
                <span class="bus-time">${b.heure}</span>
            </div>
        `;
    });
}