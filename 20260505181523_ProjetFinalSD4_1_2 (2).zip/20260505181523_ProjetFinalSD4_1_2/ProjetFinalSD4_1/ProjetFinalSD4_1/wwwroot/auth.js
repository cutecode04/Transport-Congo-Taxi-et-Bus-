﻿let isRegisterMode = false;

function switchMode() {
    isRegisterMode = !isRegisterMode;

    document.querySelectorAll(".register-field").forEach(field => {
        field.classList.toggle("hidden");
    });

    if (isRegisterMode) {
        document.getElementById("authTitle").innerText = "Bienvenue !";
        document.getElementById("authText").innerText =
            "Créez votre compte pour commander une course ou devenir chauffeur.";
        document.getElementById("formTitle").innerText = "Inscription";
        document.getElementById("mainBtn").innerText = "Créer le compte";
        document.getElementById("mainBtn").onclick = register;
        document.getElementById("switchQuestion").innerText = "Vous avez déjà un compte ?";
        document.getElementById("switchLink").innerText = "Se connecter";
    } else {
        document.getElementById("authTitle").innerText = "Bon retour !";
        document.getElementById("authText").innerText =
            "Connectez-vous pour commander une course et accéder à votre dashboard.";
        document.getElementById("formTitle").innerText = "Connexion";
        document.getElementById("mainBtn").innerText = "Se connecter";
        document.getElementById("mainBtn").onclick = login;
        document.getElementById("switchQuestion").innerText = "Vous n’avez pas de compte ?";
        document.getElementById("switchLink").innerText = "Créer un compte";
    }
}

async function login() {
    const telephone = document.getElementById("telephone").value.trim();
    const motDePasse = document.getElementById("motDePasse").value.trim();

    if (telephone === "" || motDePasse === "") {
        alert("Veuillez remplir le téléphone et le mot de passe.");
        return;
    }

    const response = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ telephone, motDePasse })
    });

    if (!response.ok) {
        alert("Téléphone ou mot de passe incorrect.");
        return;
    }

    const user = await response.json();

    localStorage.setItem("userId", user.id);
    localStorage.setItem("nom", user.nom);
    localStorage.setItem("telephone", user.telephone);
    localStorage.setItem("role", user.role);

    if (user.role === "Administrateur") {
        window.location.href = "dashboard-admin.html";
    } else if (user.role === "Chauffeur") {
        window.location.href = "dashboard-chauffeur.html";
    } else {
        window.location.href = "dashboard-client.html";
    }
}

async function register() {
    const nom = document.getElementById("nom").value.trim();
    const telephone = document.getElementById("telephone").value.trim();
    const motDePasse = document.getElementById("motDePasse").value.trim();
    const role = document.getElementById("role").value;

    if (nom === "" || telephone === "" || motDePasse === "") {
        alert("Veuillez remplir tous les champs.");
        return;
    }

    const user = {
        nom: nom,
        telephone: telephone,
        motDePasse: motDePasse,
        role: role,
        disponible: role === "Chauffeur"
    };

    const response = await fetch("/api/utilisateurs", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(user)
    });

    if (response.ok) {
        alert("Compte créé avec succès. Connectez-vous maintenant.");

        document.getElementById("nom").value = "";
        document.getElementById("telephone").value = "";
        document.getElementById("motDePasse").value = "";

        switchMode();
    } else {
        const erreur = await response.text();
        alert("Erreur inscription : " + erreur);
    }
}