﻿function continuerTrajet() {
    const depart = document.getElementById("depart").value.trim();
    const destination = document.getElementById("destination").value.trim();

    if (depart === "" || destination === "") {
        alert("Veuillez remplir le départ et la destination.");
        return;
    }

    localStorage.setItem("depart", depart);
    localStorage.setItem("destination", destination);

    window.location.href = "commande-choix.html";
}