﻿function startHomeCommande() {
    const depart = document.getElementById("homeDepart").value.trim();
    const destination = document.getElementById("homeDestination").value.trim();

    if (depart === "" || destination === "") {
        alert("Veuillez entrer le départ et la destination.");
        return;
    }

    localStorage.setItem("depart", depart);
    localStorage.setItem("destination", destination);

    if (!localStorage.getItem("userId")) {
        alert("Connectez-vous avant de commander.");
        window.location.href = "auth.html";
        return;
    }

    window.location.href = "commande-choix.html";
}