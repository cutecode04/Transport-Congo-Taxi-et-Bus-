﻿function choisirCourse(type, montant) {
    localStorage.setItem("typeCourse", type);
    localStorage.setItem("montant", montant);

    window.location.href = "commande-paiement.html";
}