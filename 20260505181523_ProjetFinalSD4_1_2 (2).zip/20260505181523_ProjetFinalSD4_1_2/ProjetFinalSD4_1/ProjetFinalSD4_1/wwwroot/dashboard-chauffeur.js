﻿let accepted = 0;

async function chargerDashboardChauffeur() {
    document.getElementById("nomChauffeur").innerText = localStorage.getItem("nom");
    document.getElementById("telChauffeur").innerText = localStorage.getItem("telephone");

    await chargerCoursesChauffeur();
}

async function chargerCoursesChauffeur() {
    const tbody = document.getElementById("coursesDisponibles");

    try {
        const res = await fetch("/api/admin/courses?role=Administrateur");
        const courses = await res.json();

        const coursesEnAttente = courses.filter(c => c.Statut === "EnAttente");

        document.getElementById("coursesDisponiblesCount").innerText = coursesEnAttente.length;

        tbody.innerHTML = "";

        if (coursesEnAttente.length === 0) {
            tbody.innerHTML = `<tr><td colspan="6">Aucune course disponible.</td></tr>`;
            return;
        }

        coursesEnAttente.forEach(c => {
            tbody.innerHTML += `
                <tr>
                    <td>Client ${c.ClientId}</td>
                    <td>${c.LieuDepart}</td>
                    <td>${c.LieuArrivee}</td>
                    <td>${c.TypeCourse}</td>
                    <td>${c.Montant} FCFA</td>
                    <td>
                        <button class="btn" onclick="accepter(${c.Id})">Accepter</button>
                        <button class="btn btn-red" onclick="refuser(${c.Id})">Refuser</button>
                    </td>
                </tr>
            `;
        });

    } catch (error) {
        console.log(error);
        tbody.innerHTML = `<tr><td colspan="6">Erreur de chargement.</td></tr>`;
    }
}

async function accepter(id) {
    const chauffeurId = localStorage.getItem("userId");

    const res = await fetch(`/api/courses/accepter/${id}?chauffeurId=${chauffeurId}`, {
        method: "PUT"
    });

    if (res.ok) {
        accepted++;
        document.getElementById("acceptedCount").innerText = accepted;
        alert("Course acceptée.");
        chargerCoursesChauffeur();
    } else {
        alert("Erreur lors de l’acceptation.");
    }
}

async function refuser(id) {
    const res = await fetch(`/api/courses/refuser/${id}`, {
        method: "PUT"
    });

    if (res.ok) {
        alert("Course refusée.");
        chargerCoursesChauffeur();
    } else {
        alert("Erreur lors du refus.");
    }
}