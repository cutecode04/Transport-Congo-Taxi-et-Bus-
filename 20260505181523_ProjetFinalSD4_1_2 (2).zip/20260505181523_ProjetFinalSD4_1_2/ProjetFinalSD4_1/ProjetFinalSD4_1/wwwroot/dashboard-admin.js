﻿async function chargerDashboardAdmin() {
    const role = localStorage.getItem("role");

    if (role !== "Administrateur") {
        alert("Accès refusé");
        window.location.href = "home.html";
        return;
    }

    try {
        // ============================
        // UTILISATEURS
        // ============================
        const usersResponse = await fetch(`/api/admin/utilisateurs?role=${role}`);
        const users = await usersResponse.json();

        const usersBody = document.getElementById("listeUtilisateurs");
        usersBody.innerHTML = "";

        document.getElementById("totalUsers").innerText = users.length;

        users.forEach(u => {
            usersBody.innerHTML += `
                <tr>
                    <td>${u.Nom}</td>
                    <td>${u.Telephone}</td>
                    <td><span class="badge">${u.Role}</span></td>
                    <td>${u.Disponible ? "Oui" : "Non"}</td>
                </tr>
            `;
        });

        // ============================
        // COURSES
        // ============================
        const coursesResponse = await fetch(`/api/admin/courses?role=${role}`);
        const courses = await coursesResponse.json();

        const coursesBody = document.getElementById("listeCoursesAdmin");
        coursesBody.innerHTML = "";

        document.getElementById("totalCoursesAdmin").innerText = courses.length;

        courses.forEach(c => {
            coursesBody.innerHTML += `
                <tr>
                    <td>${c.ClientId}</td>
                    <td>${c.LieuDepart}</td>
                    <td>${c.LieuArrivee}</td>
                    <td>${c.TypeCourse}</td>
                    <td><span class="badge">${c.Statut}</span></td>
                </tr>
            `;
        });

        // ============================
        // ACTIVITÉS RÉCENTES
        // ============================
        const activitesResponse = await fetch(`/api/admin/activites`);
        const activites = await activitesResponse.json();

        const activitesList = document.getElementById("listeActivites");

        if (activitesList) {
            activitesList.innerHTML = "";

            activites.forEach(a => {
                activitesList.innerHTML += `
                    <li>
                        Client ${a.clientId} → ${a.depart} → ${a.arrivee}
                        <br><small>${new Date(a.date).toLocaleString()}</small>
                    </li>
                `;
            });
        }

    } catch (error) {
        console.log("Erreur :", error);

        document.getElementById("listeUtilisateurs").innerHTML =
            `<tr><td colspan="4">Erreur de chargement</td></tr>`;

        document.getElementById("listeCoursesAdmin").innerHTML =
            `<tr><td colspan="5">Erreur de chargement</td></tr>`;
    }
}