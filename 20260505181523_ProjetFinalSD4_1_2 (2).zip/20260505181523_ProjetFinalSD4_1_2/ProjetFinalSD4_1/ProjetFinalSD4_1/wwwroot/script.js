﻿function goLogin() {
    window.location.href = "auth.html?v=10";
}
function goHome() {
    window.location.href = "home.html";
}
function updateMenu() {
    const role = localStorage.getItem("role");
    const profileLink = document.getElementById("profileLink");

    if (!profileLink) return;

    if (role) {
        profileLink.innerText = "Mon profil";

        if (role === "Administrateur") {
            profileLink.href = "dashboard-admin.html";
        } else if (role === "Chauffeur") {
            profileLink.href = "dashboard-chauffeur.html";
        } else {
            profileLink.href = "dashboard-client.html";
        }
    } else {
        profileLink.innerText = "Connexion";
        profileLink.href = "auth.html?v=10";
    }
}

document.addEventListener("DOMContentLoaded", updateMenu);
function goCommande() {
    if (!localStorage.getItem("userId")) {
        alert("Vous devez vous connecter avant de commander.");
        window.location.href = "auth.html?v=2";
        return;
    }

    window.location.href = "commande-trajet.html";
}
function logout() {
    localStorage.clear();
    window.location.href = "home.html";
}

function protectPage(rolesAutorises) {
    const role = localStorage.getItem("role");

    if (!role) {
        alert("Veuillez vous connecter.");
        window.location.href = "auth.html";
        return;
    }

    if (!rolesAutorises.includes(role)) {
        alert("Accès non autorisé.");
        window.location.href = "home.html";
    }
}