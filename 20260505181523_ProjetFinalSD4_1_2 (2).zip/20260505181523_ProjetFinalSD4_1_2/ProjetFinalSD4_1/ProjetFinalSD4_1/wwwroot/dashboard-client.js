﻿async function chargerDashboardClient() {
    const nom = localStorage.getItem("nom");
    const telephone = localStorage.getItem("telephone");
    const userId = localStorage.getItem("userId");

    document.getElementById("nomClient").innerText = nom;
    document.getElementById("telClient").innerText = telephone;

    try {
        const statsResponse = await fetch(`/api/courses/stats/client/${userId}`);
        const stats = await statsResponse.json();

        document.getElementById("totalCourses").innerText = stats.total;
        document.getElementById("coursesAttente").innerText = stats.enAttente;
        document.getElementById("coursesTerminees").innerText = stats.terminees;

        const coursesResponse = await fetch(`/api/courses/client/${userId}`);
        const courses = await coursesResponse.json();

        const tbody = document.getElementById("listeCoursesClient");
        tbody.innerHTML = "";

        if (courses.length === 0) {
            tbody.innerHTML = `<tr><td colspan="5">Aucune course trouvée.</td></tr>`;
            return;
        }

        courses.forEach(c => {
            tbody.innerHTML += `
                <tr>
                    <td>${c.lieuDepart}</td>
                    <td>${c.lieuArrivee}</td>
                    <td>${c.typeCourse}</td>
                    <td>${c.montant} FCFA</td>
                    <td><span class="badge">${c.statut}</span></td>
                </tr>
            `;
        });

    } catch (error) {
        console.log(error);
        document.getElementById("listeCoursesClient").innerHTML =
            `<tr><td colspan="5">Erreur de chargement.</td></tr>`;
    }
}