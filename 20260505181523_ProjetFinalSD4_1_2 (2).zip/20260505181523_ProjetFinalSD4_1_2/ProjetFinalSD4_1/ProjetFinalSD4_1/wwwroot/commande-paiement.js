﻿document.addEventListener("DOMContentLoaded", () => {
    document.getElementById("recapDepart").innerText = localStorage.getItem("depart");
    document.getElementById("recapDestination").innerText = localStorage.getItem("destination");
    document.getElementById("recapType").innerText = localStorage.getItem("typeCourse");
    document.getElementById("recapPrix").innerText = localStorage.getItem("montant");
});

async function confirmerCommande() {
    const dto = {
        clientId: parseInt(localStorage.getItem("userId")),
        lieuDepart: localStorage.getItem("depart"),
        lieuArrivee: localStorage.getItem("destination"),
        typeCourse: localStorage.getItem("typeCourse"),
        montant: parseFloat(localStorage.getItem("montant")),
        modePaiement: document.getElementById("modePaiement").value
    };

    const response = await fetch("/api/courses", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(dto)
    });

    if (response.ok) {
        window.location.href = "commande-recherche.html";
    } else {
        alert("Erreur lors de la création de la course.");
    }
}