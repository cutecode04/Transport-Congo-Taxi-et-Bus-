﻿namespace ProjetFinalSD4_1.Models
{
    public enum StatuCourse
    {
        EnAttente,
        EnCours,
        Terminee,
        Annulee
    }
}