﻿namespace ProjetFinalSD4_1.Models
{
    public class UtilisateurDTO
    {
        private int id;
        private string nom;
        private string telephone;
        private string motDePasse;
        private string role;
        private bool disponible;

        public UtilisateurDTO()
        {
            id = 0;
            nom = "";
            telephone = "";
            motDePasse = "";
            role = "Client";
            disponible = false;
        }

        public UtilisateurDTO(int id, string nom, string telephone, string motDePasse, string role, bool disponible)
        {
            this.id = id;
            this.nom = nom;
            this.telephone = telephone;
            this.motDePasse = motDePasse;
            this.role = role;
            this.disponible = disponible;
        }

        public int Id { get => id; set => id = value; }
        public string Nom { get => nom; set => nom = value; }
        public string Telephone { get => telephone; set => telephone = value; }
        public string MotDePasse { get => motDePasse; set => motDePasse = value; }
        public string Role { get => role; set => role = value; }
        public bool Disponible { get => disponible; set => disponible = value; }
    }
}