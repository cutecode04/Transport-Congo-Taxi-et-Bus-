﻿namespace ProjetFinalSD4_1.Models
{
    public class CourseDto
    {
        private int clientId;
        private string telephoneClient;
        private string lieuDepart;
        private string lieuArrivee;
        private string typeCourse;
        private decimal montant;
        private string modePaiement;

        public CourseDto()
        {
            clientId = 0;
            telephoneClient = "";
            lieuDepart = "";
            lieuArrivee = "";
            typeCourse = "";
            montant = 0;
            modePaiement = "";
        }

        public CourseDto(int clientId, string telephoneClient, string lieuDepart, string lieuArrivee,
                         string typeCourse, decimal montant, string modePaiement)
        {
            this.clientId = clientId;
            this.telephoneClient = telephoneClient;
            this.lieuDepart = lieuDepart;
            this.lieuArrivee = lieuArrivee;
            this.typeCourse = typeCourse;
            this.montant = montant;
            this.modePaiement = modePaiement;
        }

        public int ClientId { get => clientId; set => clientId = value; }
        public string TelephoneClient { get => telephoneClient; set => telephoneClient = value; }
        public string LieuDepart { get => lieuDepart; set => lieuDepart = value; }
        public string LieuArrivee { get => lieuArrivee; set => lieuArrivee = value; }
        public string TypeCourse { get => typeCourse; set => typeCourse = value; }
        public decimal Montant { get => montant; set => montant = value; }
        public string ModePaiement { get => modePaiement; set => modePaiement = value; }
    }
}