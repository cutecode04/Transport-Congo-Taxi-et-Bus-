﻿namespace ProjetFinalSD4_1.Models
{
    public class Client : Utilisateur
    {
        public Client() : base()
        {
            Role = RoleUtilisateur.Client;
        }

        public Client(int id, string nom, string telephone, string motDePasse)
            : base(id, nom, telephone, motDePasse, RoleUtilisateur.Client)
        {
        }
    }
}