﻿namespace ProjetFinalSD4_1.Models
{
    public class Chauffeur : Utilisateur
    {
        private bool disponible;

        public Chauffeur() : base()
        {
            disponible = true;
            Role = RoleUtilisateur.Chauffeur;
        }

        public Chauffeur(int id, string nom, string telephone, string motDePasse, bool disponible)
            : base(id, nom, telephone, motDePasse, RoleUtilisateur.Chauffeur)
        {
            this.disponible = disponible;
        }

        public bool Disponible { get => disponible; set => disponible = value; }
    }
}