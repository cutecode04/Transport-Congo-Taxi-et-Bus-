﻿namespace ProjetFinalSD4_1.Models
{
    public class Utilisateur
    {
        private int id;
        private string nom;
        private string telephone;
        private string motDePasse;
        private RoleUtilisateur role;

        public Utilisateur()
        {
            id = 0;
            nom = "";
            telephone = "";
            motDePasse = "";
            role = RoleUtilisateur.Client;
        }

        public Utilisateur(int id, string nom, string telephone, string motDePasse, RoleUtilisateur role)
        {
            this.id = id;
            this.nom = nom;
            this.telephone = telephone;
            this.motDePasse = motDePasse;
            this.role = role;
        }

        public int Id { get => id; set => id = value; }
        public string Nom { get => nom; set => nom = value; }
        public string Telephone { get => telephone; set => telephone = value; }
        public string MotDePasse { get => motDePasse; set => motDePasse = value; }
        public RoleUtilisateur Role { get => role; set => role = value; }
    }
}