﻿namespace ProjetFinalSD4_1.Models
{
    public class LoginDto
    {
        private string telephone;
        private string motDePasse;

        public LoginDto()
        {
            telephone = "";
            motDePasse = "";
        }

        public LoginDto(string telephone, string motDePasse)
        {
            this.telephone = telephone;
            this.motDePasse = motDePasse;
        }

        public string Telephone { get => telephone; set => telephone = value; }
        public string MotDePasse { get => motDePasse; set => motDePasse = value; }
    }
}