﻿namespace ProjetFinalSD4_1.Models
{
    public class BusHoraire
    {
        private int id;
        private string ligne;
        private string depart;
        private string arrivee;
        private string heure;
        private string frequence;

        public BusHoraire()
        {
            id = 0;
            ligne = "";
            depart = "";
            arrivee = "";
            heure = "";
            frequence = "";
        }

        public BusHoraire(int id, string ligne, string depart, string arrivee, string heure, string frequence)
        {
            this.id = id;
            this.ligne = ligne;
            this.depart = depart;
            this.arrivee = arrivee;
            this.heure = heure;
            this.frequence = frequence;
        }

        public int Id { get => id; set => id = value; }
        public string Ligne { get => ligne; set => ligne = value; }
        public string Depart { get => depart; set => depart = value; }
        public string Arrivee { get => arrivee; set => arrivee = value; }
        public string Heure { get => heure; set => heure = value; }
        public string Frequence { get => frequence; set => frequence = value; }
    }
}