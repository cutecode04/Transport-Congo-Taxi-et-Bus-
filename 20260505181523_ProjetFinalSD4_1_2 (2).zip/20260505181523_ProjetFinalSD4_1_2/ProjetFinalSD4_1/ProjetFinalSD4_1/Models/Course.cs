﻿namespace ProjetFinalSD4_1.Models
{
    public class Course
    {
        private int id;
        private int clientId;
        private int? chauffeurId;
        private string lieuDepart;
        private string lieuArrivee;
        private string typeCourse;
        private decimal montant;
        private string modePaiement;
        private StatuCourse statut;
        private DateTime dateCommande;

        public Course()
        {
            id = 0;
            clientId = 0;
            chauffeurId = null;
            lieuDepart = "";
            lieuArrivee = "";
            typeCourse = "";
            montant = 0;
            modePaiement = "";
            statut = StatuCourse.EnAttente;
            dateCommande = DateTime.Now;
        }

        public Course(int id, int clientId, int? chauffeurId, string lieuDepart, string lieuArrivee,
                      string typeCourse, decimal montant, string modePaiement, StatuCourse statut)
        {
            this.id = id;
            this.clientId = clientId;
            this.chauffeurId = chauffeurId;
            this.lieuDepart = lieuDepart;
            this.lieuArrivee = lieuArrivee;
            this.typeCourse = typeCourse;
            this.montant = montant;
            this.modePaiement = modePaiement;
            this.statut = statut;
            this.dateCommande = DateTime.Now;
        }

        public int Id { get => id; set => id = value; }
        public int ClientId { get => clientId; set => clientId = value; }
        public int? ChauffeurId { get => chauffeurId; set => chauffeurId = value; }
        public string LieuDepart { get => lieuDepart; set => lieuDepart = value; }
        public string LieuArrivee { get => lieuArrivee; set => lieuArrivee = value; }
        public string TypeCourse { get => typeCourse; set => typeCourse = value; }
        public decimal Montant { get => montant; set => montant = value; }
        public string ModePaiement { get => modePaiement; set => modePaiement = value; }
        public StatuCourse Statut { get => statut; set => statut = value; }
        public DateTime DateCommande { get => dateCommande; set => dateCommande = value; }
    }
}