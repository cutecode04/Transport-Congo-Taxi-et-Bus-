﻿namespace ProjetFinalSD4_1.Models
{
    public enum RoleUtilisateur
    {
        Administrateur,
        Client,
        Chauffeur
    }
}