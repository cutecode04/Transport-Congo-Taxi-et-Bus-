﻿using Microsoft.Data.SqlClient;

namespace ProjetFinalSD4_1.Data
{
    public class BaseDeDonnee
    {

        private static IConfiguration _config;

        public static void Init(IConfiguration config)
        {
            _config = config;
        }

        public static SqlConnection GetConnection()
        {
            string connectionString =
                _config.GetConnectionString("DefaultConnection");

            return new SqlConnection(connectionString);
        }

    }
}
